# AESCryptoDLL

C++ DLL to perform AES-256-CBC encryption and decryption compatible with PHP's OpenSSL AES logic.

## Features
- Matches PHP-style AES-256-CBC `encrypt_decrypt()` behavior.
- Uses OpenSSL
- Returns base64 encoded cipher text with IV appended using `::` separator

## Build Instructions
- Open in Visual Studio
- Link against OpenSSL libraries (`libcrypto.lib` and `libssl.lib`)
- Compile as DLL (both 32-bit and 64-bit projects recommended)

## Delphi Usage Example
```
function EncryptAES(Text, Key: PAnsiChar): PAnsiChar; stdcall; external 'AESCryptoDLL.dll';
```