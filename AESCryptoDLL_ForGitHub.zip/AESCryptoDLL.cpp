#include "AESCryptoDLL.h"
#include <windows.h>
#include <string>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/err.h>
#include <vector>
#include <sstream>
#include <iomanip>

static std::string lastResult;

std::string base64_encode(const std::string& in) {
    BIO* bio, * b64;
    BUF_MEM* bufferPtr;
    b64 = BIO_new(BIO_f_base64());
    bio = BIO_new(BIO_s_mem());
    bio = BIO_push(b64, bio);
    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL);
    BIO_write(bio, in.c_str(), in.length());
    BIO_flush(bio);
    BIO_get_mem_ptr(bio, &bufferPtr);
    std::string result(bufferPtr->data, bufferPtr->length);
    BIO_free_all(bio);
    return result;
}

std::string base64_decode(const std::string& in) {
    BIO* bio, * b64;
    int decodeLen = in.length();
    char* buffer = (char*)malloc(decodeLen);
    memset(buffer, 0, decodeLen);
    b64 = BIO_new(BIO_f_base64());
    bio = BIO_new_mem_buf(in.c_str(), -1);
    bio = BIO_push(b64, bio);
    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL);
    int length = BIO_read(bio, buffer, decodeLen);
    std::string result(buffer, length);
    BIO_free_all(bio);
    free(buffer);
    return result;
}

std::string aes_encrypt(const std::string& plaintext, const std::string& key) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    std::string output;

    unsigned char iv[16];
    RAND_bytes(iv, sizeof(iv));

    std::vector<unsigned char> outbuf(plaintext.size() + EVP_MAX_BLOCK_LENGTH);
    int outlen1 = 0, outlen2 = 0;

    EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, (unsigned char*)key.c_str(), iv);
    EVP_EncryptUpdate(ctx, outbuf.data(), &outlen1, (unsigned char*)plaintext.c_str(), plaintext.size());
    EVP_EncryptFinal_ex(ctx, outbuf.data() + outlen1, &outlen2);
    EVP_CIPHER_CTX_free(ctx);

    std::string cipher(reinterpret_cast<char*>(outbuf.data()), outlen1 + outlen2);
    std::string combined = cipher + "::" + std::string(reinterpret_cast<char*>(iv), 16);
    return base64_encode(combined);
}

std::string aes_decrypt(const std::string& ciphertext_b64, const std::string& key) {
    std::string decoded = base64_decode(ciphertext_b64);
    auto pos = decoded.find("::");
    if (pos == std::string::npos) return "";

    std::string encrypted = decoded.substr(0, pos);
    std::string iv = decoded.substr(pos + 2);

    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    std::vector<unsigned char> outbuf(encrypted.size() + EVP_MAX_BLOCK_LENGTH);
    int outlen1 = 0, outlen2 = 0;

    EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, (unsigned char*)key.c_str(), (unsigned char*)iv.c_str());
    EVP_DecryptUpdate(ctx, outbuf.data(), &outlen1, (unsigned char*)encrypted.c_str(), encrypted.size());
    EVP_DecryptFinal_ex(ctx, outbuf.data() + outlen1, &outlen2);
    EVP_CIPHER_CTX_free(ctx);

    return std::string(reinterpret_cast<char*>(outbuf.data()), outlen1 + outlen2);
}

extern "C" {
    AESCryptoDLL_API const char* __stdcall EncryptAES(const char* plainText, const char* key) {
        lastResult = aes_encrypt(plainText, key);
        return lastResult.c_str();
    }

    AESCryptoDLL_API const char* __stdcall DecryptAES(const char* cipherText, const char* key) {
        lastResult = aes_decrypt(cipherText, key);
        return lastResult.c_str();
    }
}