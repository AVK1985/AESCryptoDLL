#pragma once

#ifdef AESCryptoDLL_EXPORTS
#define AESCryptoDLL_API __declspec(dllexport)
#else
#define AESCryptoDLL_API __declspec(dllimport)
#endif

extern "C" {
    AESCryptoDLL_API const char* __stdcall EncryptAES(const char* plainText, const char* key);
    AESCryptoDLL_API const char* __stdcall DecryptAES(const char* cipherText, const char* key);
}